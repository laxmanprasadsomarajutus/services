import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Instagram, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5">
          <div className="space-y-4">
            <Link href="/" className="flex items-center space-x-2">
              <span className="font-bold text-xl">HomeShare</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Connecting trusted professionals and intergenerational homesharing across Ireland.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Services</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/services/cleaning" className="text-muted-foreground hover:text-foreground">
                  Cleaning
                </Link>
              </li>
              <li>
                <Link href="/services/plumbing" className="text-muted-foreground hover:text-foreground">
                  Plumbing
                </Link>
              </li>
              <li>
                <Link href="/services/electrical" className="text-muted-foreground hover:text-foreground">
                  Electrical
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-muted-foreground hover:text-foreground">
                  View All Services
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Homesharing</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/homesharing/householders" className="text-muted-foreground hover:text-foreground">
                  For Householders
                </Link>
              </li>
              <li>
                <Link href="/homesharing/homesharers" className="text-muted-foreground hover:text-foreground">
                  For Students
                </Link>
              </li>
              <li>
                <Link href="/homesharing/how-it-works" className="text-muted-foreground hover:text-foreground">
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="/homesharing/success-stories" className="text-muted-foreground hover:text-foreground">
                  Success Stories
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Company</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-muted-foreground hover:text-foreground">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-foreground">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Subscribe to our newsletter</h4>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input placeholder="Enter your email" type="email" className="max-w-[300px]" />
              <Button type="submit" size="sm">
                Subscribe
              </Button>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} HomeShare. All rights reserved.</p>
          <div className="mt-2 flex justify-center space-x-4">
            <Link href="/terms" className="hover:text-foreground">
              Terms of Service
            </Link>
            <Link href="/privacy" className="hover:text-foreground">
              Privacy Policy
            </Link>
            <Link href="/cookies" className="hover:text-foreground">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

