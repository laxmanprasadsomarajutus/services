import { useApi } from "../context/api-context"
import firebase from "firebase/app"
import "firebase/firestore"

// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp({
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: import.meta.env.VITE_FIREBASE_APP_ID,
  })
}

const db = firebase.firestore()

// This is a service module that provides functions to interact with the chat API
export const useChatApi = () => {
  const { api } = useApi()

  return {
    // Get all conversations for the current user
    getConversations: async () => {
      try {
        const response = await api.get("/chat/conversations")
        return response.data
      } catch (error) {
        console.error("Error fetching conversations:", error)
        throw error
      }
    },

    // Get messages for a specific conversation
    getMessages: async (conversationId) => {
      try {
        // Get messages from Firestore
        const messagesRef = db.collection("conversations").doc(conversationId).collection("messages")
        const snapshot = await messagesRef.orderBy("timestamp").get()

        return snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }))
      } catch (error) {
        console.error(`Error fetching messages for conversation ${conversationId}:`, error)
        throw error
      }
    },

    // Send a message in a conversation
    sendMessage: async (conversationId, message) => {
      try {
        // Add message to Firestore
        const messagesRef = db.collection("conversations").doc(conversationId).collection("messages")
        await messagesRef.add({
          ...message,
          timestamp: firebase.firestore.FieldValue.serverTimestamp(),
        })

        // Update conversation last message on backend
        await api.put(`/chat/conversations/${conversationId}/last-message`, {
          lastMessage: message.text,
          timestamp: new Date().toISOString(),
        })

        return { success: true }
      } catch (error) {
        console.error(`Error sending message in conversation ${conversationId}:`, error)
        throw error
      }
    },

    // Create a new conversation
    createConversation: async (participantId) => {
      try {
        const response = await api.post("/chat/conversations", { participantId })

        // Initialize conversation in Firestore
        await db.collection("conversations").doc(response.data.id).set({
          participants: response.data.participants,
          createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        })

        return response.data
      } catch (error) {
        console.error("Error creating conversation:", error)
        throw error
      }
    },

    // Subscribe to messages in a conversation (real-time updates)
    subscribeToMessages: (conversationId, callback) => {
      const messagesRef = db.collection("conversations").doc(conversationId).collection("messages")
      return messagesRef.orderBy("timestamp").onSnapshot((snapshot) => {
        const messages = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }))
        callback(messages)
      })
    },
  }
}

