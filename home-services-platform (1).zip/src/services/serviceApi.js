import { useApi } from "../context/api-context"

// This is a service module that provides functions to interact with the services API
export const useServiceApi = () => {
  const { api } = useApi()

  return {
    // Get all services with optional filters
    getServices: async (filters = {}) => {
      try {
        const response = await api.get("/services", { params: filters })
        return response.data
      } catch (error) {
        console.error("Error fetching services:", error)
        throw error
      }
    },

    // Get a single service by ID
    getServiceById: async (id) => {
      try {
        const response = await api.get(`/services/${id}`)
        return response.data
      } catch (error) {
        console.error(`Error fetching service with ID ${id}:`, error)
        throw error
      }
    },

    // Create a booking for a service
    createBooking: async (bookingData) => {
      try {
        const response = await api.post("/bookings", bookingData)
        return response.data
      } catch (error) {
        console.error("Error creating booking:", error)
        throw error
      }
    },

    // Get user's bookings
    getUserBookings: async () => {
      try {
        const response = await api.get("/bookings/user")
        return response.data
      } catch (error) {
        console.error("Error fetching user bookings:", error)
        throw error
      }
    },

    // Submit a review for a service
    submitReview: async (serviceId, reviewData) => {
      try {
        const response = await api.post(`/services/${serviceId}/reviews`, reviewData)
        return response.data
      } catch (error) {
        console.error("Error submitting review:", error)
        throw error
      }
    },

    // Get reviews for a service
    getServiceReviews: async (serviceId) => {
      try {
        const response = await api.get(`/services/${serviceId}/reviews`)
        return response.data
      } catch (error) {
        console.error(`Error fetching reviews for service ${serviceId}:`, error)
        throw error
      }
    },
  }
}

