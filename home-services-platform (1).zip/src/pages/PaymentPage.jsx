"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { CardElement, useStripe, useElements, Elements } from "@stripe/react-stripe-js"
import { loadStripe } from "@stripe/stripe-js"
import Layout from "../components/layout/Layout"
import { Button } from "../components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { useToast } from "../components/ui/use-toast"
import { usePaymentApi } from "../services/paymentApi"

// Load Stripe outside of component to avoid recreating it on renders
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)

function PaymentForm() {
  const { bookingId } = useParams()
  const navigate = useNavigate()
  const { toast } = useToast()
  const stripe = useStripe()
  const elements = useElements()
  const paymentApi = usePaymentApi()

  const [loading, setLoading] = useState(false)
  const [booking, setBooking] = useState(null)
  const [clientSecret, setClientSecret] = useState("")

  useEffect(() => {
    // Fetch booking details and create payment intent
    const fetchBookingAndCreateIntent = async () => {
      try {
        // In a real app, you would fetch the booking details here
        // For now, we'll use mock data
        const mockBooking = {
          id: bookingId,
          service: "Professional House Cleaning",
          date: "2023-06-15T10:00:00Z",
          price: 120,
          currency: "EUR",
        }
        setBooking(mockBooking)

        // Create payment intent
        const { clientSecret } = await paymentApi.createPaymentIntent(bookingId)
        setClientSecret(clientSecret)
      } catch (error) {
        toast({
          title: "Error",
          description: error.message || "Failed to load payment information",
          variant: "destructive",
        })
      }
    }

    fetchBookingAndCreateIntent()
  }, [bookingId])

  const handleSubmit = async (event) => {
    event.preventDefault()

    if (!stripe || !elements) {
      return
    }

    setLoading(true)

    try {
      const cardElement = elements.getElement(CardElement)

      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement,
      })

      if (error) {
        throw new Error(error.message)
      }

      // Process the payment
      await paymentApi.processPayment(clientSecret, paymentMethod.id)

      toast({
        title: "Payment Successful",
        description: "Your booking has been confirmed",
      })

      navigate(`/booking/confirm/${bookingId}`)
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: error.message || "There was a problem processing your payment",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (!booking) {
    return <div className="flex justify-center p-8">Loading booking details...</div>
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-4">
        <div className="rounded-md border p-4">
          <h3 className="font-medium mb-2">Payment Details</h3>
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: "16px",
                  color: "#424770",
                  "::placeholder": {
                    color: "#aab7c4",
                  },
                },
                invalid: {
                  color: "#9e2146",
                },
              },
            }}
          />
        </div>

        <div className="rounded-md border p-4">
          <div className="flex justify-between mb-2">
            <span>Service:</span>
            <span>{booking.service}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Date:</span>
            <span>{new Date(booking.date).toLocaleString()}</span>
          </div>
          <div className="flex justify-between font-bold">
            <span>Total:</span>
            <span>
              {booking.price} {booking.currency}
            </span>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <Button type="submit" className="w-full" disabled={!stripe || loading}>
          {loading ? "Processing..." : `Pay ${booking.price} ${booking.currency}`}
        </Button>
      </div>
    </form>
  )
}

function PaymentPage() {
  return (
    <Layout>
      <div className="container max-w-md mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Complete Your Payment</CardTitle>
            <CardDescription>Secure payment processing by Stripe</CardDescription>
          </CardHeader>
          <CardContent>
            <Elements stripe={stripePromise}>
              <PaymentForm />
            </Elements>
          </CardContent>
          <CardFooter className="flex justify-center text-sm text-muted-foreground">
            <p>Your payment information is securely processed by Stripe.</p>
          </CardFooter>
        </Card>
      </div>
    </Layout>
  )
}

export default PaymentPage

