import Layout from "../components/layout/Layout"
import { HeroSection } from "../components/home/HeroSection"
import { ServiceCategories } from "../components/home/ServiceCategories"
import { HowItWorks } from "../components/home/HowItWorks"
import { HomesharingIntro } from "../components/home/HomesharingIntro"

function HomePage() {
  return (
    <Layout>
      <HeroSection />
      <ServiceCategories />
      <HowItWorks />
      <HomesharingIntro />
    </Layout>
  )
}

export default HomePage

