import { Link } from "react-router-dom"
import { Button } from "../components/ui/button"
import Layout from "../components/layout/Layout"

function NotFoundPage() {
  return (
    <Layout>
      <div className="container flex flex-col items-center justify-center min-h-[70vh] px-4 py-12 text-center">
        <h1 className="text-6xl font-bold">404</h1>
        <h2 className="mt-4 text-2xl font-semibold">Page Not Found</h2>
        <p className="mt-2 text-muted-foreground">The page you're looking for doesn't exist or has been moved.</p>
        <Button className="mt-6" asChild>
          <Link to="/">Return Home</Link>
        </Button>
      </div>
    </Layout>
  )
}

export default NotFoundPage

