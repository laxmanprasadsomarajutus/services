"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { MainNav } from "@/components/main-nav"
import { Calendar, Clock, DollarSign, Users } from "lucide-react"

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [user, loading, router])

  if (loading || !user) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <MainNav />
        </div>
      </header>
      <main className="flex-1 p-4 md:p-8">
        <div className="flex flex-col space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, {user.name || user.email}!</p>
          </div>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="bookings">Bookings</TabsTrigger>
              <TabsTrigger value="messages">Messages</TabsTrigger>
              <TabsTrigger value="payments">Payments</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">12</div>
                    <p className="text-xs text-muted-foreground">+2 from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Upcoming Services</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">3</div>
                    <p className="text-xs text-muted-foreground">Next: Cleaning on Friday</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">€420</div>
                    <p className="text-xs text-muted-foreground">+€85 from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Saved Professionals</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">7</div>
                    <p className="text-xs text-muted-foreground">Across 4 service categories</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center gap-4 rounded-lg border p-3">
                          <div className="flex-1 space-y-1">
                            <p className="text-sm font-medium leading-none">
                              {i === 1
                                ? "Plumbing service completed"
                                : i === 2
                                  ? "New message from John (Electrician)"
                                  : "Payment processed"}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {i === 1 ? "2 hours ago" : i === 2 ? "Yesterday" : "3 days ago"}
                            </p>
                          </div>
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card className="col-span-3">
                  <CardHeader>
                    <CardTitle>Recommended Services</CardTitle>
                    <CardDescription>Based on your previous bookings</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {["Deep Cleaning", "Smart Home Setup", "Garden Maintenance"].map((service) => (
                        <div key={service} className="flex items-center gap-4 rounded-lg border p-3">
                          <div className="flex-1 space-y-1">
                            <p className="text-sm font-medium leading-none">{service}</p>
                          </div>
                          <Button variant="outline" size="sm">
                            Book
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="bookings" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Your Bookings</CardTitle>
                  <CardDescription>View and manage your service bookings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      "Cleaning Service - May 15, 2023",
                      "Plumbing Repair - April 28, 2023",
                      "Electrical Work - April 10, 2023",
                    ].map((booking) => (
                      <div key={booking} className="flex items-center justify-between gap-4 rounded-lg border p-4">
                        <div className="space-y-1">
                          <p className="font-medium">{booking}</p>
                          <p className="text-sm text-muted-foreground">
                            {booking.includes("Cleaning")
                              ? "Standard cleaning, 3 hours"
                              : booking.includes("Plumbing")
                                ? "Leak repair in bathroom"
                                : "Light fixture installation"}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            Details
                          </Button>
                          {booking.includes("May") && (
                            <Button variant="outline" size="sm">
                              Reschedule
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="messages" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Messages</CardTitle>
                  <CardDescription>Communicate with service providers and homesharers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {["John (Electrician)", "Maria (Cleaner)", "David (Plumber)"].map((contact) => (
                      <div key={contact} className="flex items-center justify-between gap-4 rounded-lg border p-4">
                        <div className="flex items-center gap-4">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            {contact.charAt(0)}
                          </div>
                          <div className="space-y-1">
                            <p className="font-medium">{contact}</p>
                            <p className="text-sm text-muted-foreground">
                              {contact.includes("John")
                                ? "I'll be there at 3 PM tomorrow"
                                : contact.includes("Maria")
                                  ? "Thanks for your booking!"
                                  : "The repair is complete"}
                            </p>
                          </div>
                        </div>
                        <Button size="sm">Reply</Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="payments" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Payment History</CardTitle>
                  <CardDescription>View your payment history and invoices</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { service: "Cleaning Service", date: "May 15, 2023", amount: "€120" },
                      { service: "Plumbing Repair", date: "April 28, 2023", amount: "€85" },
                      { service: "Electrical Work", date: "April 10, 2023", amount: "€150" },
                    ].map((payment) => (
                      <div
                        key={payment.service}
                        className="flex items-center justify-between gap-4 rounded-lg border p-4"
                      >
                        <div className="space-y-1">
                          <p className="font-medium">{payment.service}</p>
                          <p className="text-sm text-muted-foreground">{payment.date}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <p className="font-medium">{payment.amount}</p>
                          <Button variant="outline" size="sm">
                            Invoice
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

