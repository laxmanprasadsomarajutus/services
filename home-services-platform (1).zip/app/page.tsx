import { HeroSection } from "@/components/hero-section"
import { ServiceCategories } from "@/components/service-categories"
import { HowItWorks } from "@/components/how-it-works"
import { HomesharingIntro } from "@/components/homesharing-intro"
import { Footer } from "@/components/footer"
import { MainNav } from "@/components/main-nav"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <MainNav />
        </div>
      </header>
      <main className="flex-1">
        <HeroSection />
        <ServiceCategories />
        <HowItWorks />
        <HomesharingIntro />
      </main>
      <Footer />
    </div>
  )
}

