import { useApi } from "../utils/api-provider"

// This is a service module that provides functions to interact with the homesharing API
export const useHomesharingApi = () => {
  const { api } = useApi()

  return {
    // Get all householders
    getHouseholders: async (filters = {}) => {
      try {
        const response = await api.get("/homesharing/householders", { params: filters })
        return response.data
      } catch (error) {
        console.error("Error fetching householders:", error)
        throw error
      }
    },

    // Get all homesharers (students)
    getHomesharers: async (filters = {}) => {
      try {
        const response = await api.get("/homesharing/homesharers", { params: filters })
        return response.data
      } catch (error) {
        console.error("Error fetching homesharers:", error)
        throw error
      }
    },

    // Get a single householder profile by ID
    getHouseholderById: async (id) => {
      try {
        const response = await api.get(`/homesharing/householders/${id}`)
        return response.data
      } catch (error) {
        console.error(`Error fetching householder with ID ${id}:`, error)
        throw error
      }
    },

    // Get a single homesharer profile by ID
    getHomesharerById: async (id) => {
      try {
        const response = await api.get(`/homesharing/homesharers/${id}`)
        return response.data
      } catch (error) {
        console.error(`Error fetching homesharer with ID ${id}:`, error)
        throw error
      }
    },

    // Create or update a householder profile
    updateHouseholderProfile: async (profileData) => {
      try {
        const response = await api.post("/homesharing/householders/profile", profileData)
        return response.data
      } catch (error) {
        console.error("Error updating householder profile:", error)
        throw error
      }
    },

    // Create or update a homesharer profile
    updateHomesharerProfile: async (profileData) => {
      try {
        const response = await api.post("/homesharing/homesharers/profile", profileData)
        return response.data
      } catch (error) {
        console.error("Error updating homesharer profile:", error)
        throw error
      }
    },

    // Send a homesharing request
    sendHomesharingRequest: async (requestData) => {
      try {
        const response = await api.post("/homesharing/requests", requestData)
        return response.data
      } catch (error) {
        console.error("Error sending homesharing request:", error)
        throw error
      }
    },

    // Get homesharing requests for the current user
    getUserHomesharingRequests: async () => {
      try {
        const response = await api.get("/homesharing/requests/user")
        return response.data
      } catch (error) {
        console.error("Error fetching user homesharing requests:", error)
        throw error
      }
    },

    // Respond to a homesharing request (accept/reject)
    respondToHomesharingRequest: async (requestId, status) => {
      try {
        const response = await api.put(`/homesharing/requests/${requestId}`, { status })
        return response.data
      } catch (error) {
        console.error(`Error responding to homesharing request ${requestId}:`, error)
        throw error
      }
    },
  }
}

