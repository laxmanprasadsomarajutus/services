import { useApi } from "../context/api-context"
import { loadStripe } from "@stripe/stripe-js"

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)

// This is a service module that provides functions to interact with the payment API
export const usePaymentApi = () => {
  const { api } = useApi()

  return {
    // Create a payment intent for a booking
    createPaymentIntent: async (bookingId) => {
      try {
        const response = await api.post(`/payments/create-intent/${bookingId}`)
        return response.data
      } catch (error) {
        console.error(`Error creating payment intent for booking ${bookingId}:`, error)
        throw error
      }
    },

    // Process a payment with Stripe
    processPayment: async (paymentIntentId, paymentMethodId) => {
      try {
        const stripe = await stripePromise
        const result = await stripe.confirmCardPayment(paymentIntentId, {
          payment_method: paymentMethodId,
        })

        if (result.error) {
          throw new Error(result.error.message)
        }

        return result.paymentIntent
      } catch (error) {
        console.error("Error processing payment:", error)
        throw error
      }
    },

    // Get payment history for the current user
    getPaymentHistory: async () => {
      try {
        const response = await api.get("/payments/history")
        return response.data
      } catch (error) {
        console.error("Error fetching payment history:", error)
        throw error
      }
    },

    // Get a single payment by ID
    getPaymentById: async (paymentId) => {
      try {
        const response = await api.get(`/payments/${paymentId}`)
        return response.data
      } catch (error) {
        console.error(`Error fetching payment with ID ${paymentId}:`, error)
        throw error
      }
    },
  }
}

