import Layout from "../layout/Layout"
import { HeroSection } from "../sections/HeroSection"
import { ServiceCategories } from "../sections/ServiceCategories"
import { HowItWorks } from "../sections/HowItWorks"
import { HomesharingIntro } from "../sections/HomesharingIntro"

function HomePage() {
  return (
    <Layout>
      <HeroSection />
      <ServiceCategories />
      <HowItWorks />
      <HomesharingIntro />
    </Layout>
  )
}

export default HomePage

