"use client"

import { useState, useEffect, useRef } from "react"
import Layout from "../components/layout/Layout"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { useAuth } from "../context/auth-context"
import { useChatApi } from "../services/chatApi"
import { Send, User } from "lucide-react"

function ChatPage() {
  const { user } = useAuth()
  const chatApi = useChatApi()
  const [conversations, setConversations] = useState([])
  const [activeConversation, setActiveConversation] = useState(null)
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const messagesEndRef = useRef(null)

  // Fetch conversations on component mount
  useEffect(() => {
    const fetchConversations = async () => {
      try {
        const data = await chatApi.getConversations()
        setConversations(data)
        setLoading(false)

        // Set first conversation as active if available
        if (data.length > 0 && !activeConversation) {
          setActiveConversation(data[0])
        }
      } catch (error) {
        console.error("Error fetching conversations:", error)
        setLoading(false)
      }
    }

    fetchConversations()
  }, [])

  // Subscribe to messages when active conversation changes
  useEffect(() => {
    if (!activeConversation) return

    // Fetch initial messages
    const fetchMessages = async () => {
      try {
        const data = await chatApi.getMessages(activeConversation.id)
        setMessages(data)
      } catch (error) {
        console.error("Error fetching messages:", error)
      }
    }

    fetchMessages()

    // Subscribe to real-time updates
    const unsubscribe = chatApi.subscribeToMessages(activeConversation.id, (updatedMessages) => {
      setMessages(updatedMessages)
    })

    // Cleanup subscription on unmount or when conversation changes
    return () => unsubscribe()
  }, [activeConversation])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async (e) => {
    e.preventDefault()

    if (!newMessage.trim() || !activeConversation) return

    try {
      await chatApi.sendMessage(activeConversation.id, {
        text: newMessage,
        senderId: user.id,
        senderName: user.name,
      })

      setNewMessage("")
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  const selectConversation = (conversation) => {
    setActiveConversation(conversation)
  }

  if (loading) {
    return (
      <Layout>
        <div className="container py-8">
          <div className="flex justify-center">
            <p>Loading conversations...</p>
          </div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="container py-8">
        <Card className="h-[calc(100vh-200px)] flex flex-col">
          <CardHeader className="pb-2">
            <CardTitle>Messages</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 p-0 overflow-hidden">
            <div className="grid grid-cols-12 h-full">
              {/* Conversations List */}
              <div className="col-span-3 border-r h-full overflow-y-auto">
                {conversations.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">No conversations yet</div>
                ) : (
                  <div className="divide-y">
                    {conversations.map((conversation) => (
                      <div
                        key={conversation.id}
                        className={`p-4 cursor-pointer hover:bg-muted ${
                          activeConversation?.id === conversation.id ? "bg-muted" : ""
                        }`}
                        onClick={() => selectConversation(conversation)}
                      >
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <User className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{conversation.participantName}</p>
                            <p className="text-sm text-muted-foreground truncate">
                              {conversation.lastMessage || "No messages yet"}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Messages Area */}
              <div className="col-span-9 flex flex-col h-full">
                {activeConversation ? (
                  <>
                    <div className="p-4 border-b">
                      <h3 className="font-medium">{activeConversation.participantName}</h3>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                      {messages.length === 0 ? (
                        <div className="text-center text-muted-foreground py-8">
                          No messages yet. Start the conversation!
                        </div>
                      ) : (
                        messages.map((message) => (
                          <div
                            key={message.id}
                            className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}
                          >
                            <div
                              className={`max-w-[70%] rounded-lg p-3 ${
                                message.senderId === user.id ? "bg-primary text-primary-foreground" : "bg-muted"
                              }`}
                            >
                              <p>{message.text}</p>
                              <p className="text-xs mt-1 opacity-70">
                                {message.timestamp?.toDate().toLocaleTimeString() || "Sending..."}
                              </p>
                            </div>
                          </div>
                        ))
                      )}
                      <div ref={messagesEndRef} />
                    </div>

                    <form onSubmit={handleSendMessage} className="p-4 border-t">
                      <div className="flex gap-2">
                        <Input
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          placeholder="Type a message..."
                          className="flex-1"
                        />
                        <Button type="submit" size="icon">
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </form>
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    Select a conversation to start chatting
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

export default ChatPage

