"use client"

import { useState } from "react"
import { Link, useParams } from "react-router-dom"
import { Button } from "../components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs"
import Layout from "../components/layout/Layout"
import { Star, MapPin, Clock, ChevronLeft } from "lucide-react"
import Calendar from "react-calendar"
import "react-calendar/dist/Calendar.css"

// Mock data for a service
const serviceData = {
  id: 1,
  title: "Professional House Cleaning",
  category: "Cleaning",
  description:
    "Our professional cleaning service covers all aspects of home cleaning, including dusting, vacuuming, mopping, bathroom cleaning, kitchen cleaning, and more. We use eco-friendly products and ensure your home is spotless.",
  rating: 4.8,
  reviewCount: 124,
  price: "From €60",
  location: "Dublin",
  provider: {
    name: "CleanHome Services",
    rating: 4.9,
    reviewCount: 342,
    verified: true,
    image: "/placeholder.svg?height=100&width=100",
  },
  images: [
    "/placeholder.svg?height=300&width=500",
    "/placeholder.svg?height=300&width=500",
    "/placeholder.svg?height=300&width=500",
  ],
  services: [
    {
      name: "Standard Cleaning",
      description: "Regular cleaning of living spaces, kitchen, and bathrooms",
      duration: "2-3 hours",
      price: "€60",
    },
    {
      name: "Deep Cleaning",
      description: "Thorough cleaning including hard-to-reach areas, inside appliances, etc.",
      duration: "4-6 hours",
      price: "€120",
    },
    {
      name: "Move-in/Move-out Cleaning",
      description: "Complete cleaning for new or vacated properties",
      duration: "5-7 hours",
      price: "€150",
    },
  ],
  reviews: [
    {
      id: 1,
      user: "Sarah M.",
      rating: 5,
      date: "May 10, 2023",
      comment: "Excellent service! My house has never been cleaner. The team was professional and thorough.",
    },
    {
      id: 2,
      user: "John D.",
      rating: 4,
      date: "April 28, 2023",
      comment:
        "Good job overall. They missed a few spots under the furniture but came back to fix it when I pointed it out.",
    },
    {
      id: 3,
      user: "Emma L.",
      rating: 5,
      date: "April 15, 2023",
      comment: "I've been using this service monthly for the past year and they never disappoint. Highly recommended!",
    },
  ],
}

function ServiceDetailPage() {
  const { id } = useParams()
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [selectedService, setSelectedService] = useState(serviceData.services[0])

  return (
    <Layout>
      <div className="container px-4 py-6 md:px-6 md:py-12">
        <Link to="/services" className="flex items-center text-sm text-muted-foreground hover:text-foreground mb-6">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Services
        </Link>

        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
          <div className="space-y-6">
            <div className="overflow-hidden rounded-lg">
              <img
                src={serviceData.images[0] || "/placeholder.svg"}
                alt={serviceData.title}
                className="aspect-video w-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {serviceData.images.slice(1).map((image, index) => (
                <div key={index} className="overflow-hidden rounded-lg">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`${serviceData.title} ${index + 2}`}
                    className="aspect-video w-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2">
                <div className="rounded-full px-2 py-1 text-xs font-medium bg-primary/10 text-primary">
                  {serviceData.category}
                </div>
                <div className="flex items-center text-sm">
                  <Star className="h-4 w-4 fill-primary text-primary mr-1" />
                  <span>{serviceData.rating}</span>
                  <span className="text-muted-foreground ml-1">({serviceData.reviewCount} reviews)</span>
                </div>
              </div>
              <h1 className="mt-2 text-3xl font-bold">{serviceData.title}</h1>
              <div className="mt-2 flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                {serviceData.location}
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-lg border p-4">
              <div className="h-12 w-12 overflow-hidden rounded-full">
                <img
                  src={serviceData.provider.image || "/placeholder.svg"}
                  alt={serviceData.provider.name}
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">{serviceData.provider.name}</h3>
                <div className="flex items-center text-sm">
                  <Star className="h-3 w-3 fill-primary text-primary mr-1" />
                  <span>{serviceData.provider.rating}</span>
                  <span className="text-muted-foreground ml-1">({serviceData.provider.reviewCount} reviews)</span>
                </div>
              </div>
              <div className="rounded-full px-2 py-1 text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                Verified
              </div>
            </div>

            <div>
              <h2 className="text-xl font-bold">About this service</h2>
              <p className="mt-2 text-muted-foreground">{serviceData.description}</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Book this service</CardTitle>
                <CardDescription>Select a service type, date, and time</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">Service Type</h3>
                  <div className="grid gap-2">
                    {serviceData.services.map((service) => (
                      <div
                        key={service.name}
                        className={`flex cursor-pointer items-center justify-between rounded-lg border p-3 ${
                          selectedService.name === service.name ? "border-primary bg-primary/5" : ""
                        }`}
                        onClick={() => setSelectedService(service)}
                      >
                        <div className="space-y-0.5">
                          <div className="font-medium">{service.name}</div>
                          <div className="text-sm text-muted-foreground">{service.description}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">{service.price}</div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Clock className="mr-1 h-3 w-3" />
                            {service.duration}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">Select Date</h3>
                  <div className="rounded-md border p-2">
                    <Calendar onChange={setSelectedDate} value={selectedDate} minDate={new Date()} className="w-full" />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Book Now</Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        <div className="mt-12">
          <Tabs defaultValue="reviews">
            <TabsList className="w-full max-w-md">
              <TabsTrigger value="reviews" className="flex-1">
                Reviews
              </TabsTrigger>
              <TabsTrigger value="faq" className="flex-1">
                FAQ
              </TabsTrigger>
              <TabsTrigger value="policies" className="flex-1">
                Policies
              </TabsTrigger>
            </TabsList>
            <TabsContent value="reviews" className="mt-6 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Customer Reviews</h2>
                <Button>Write a Review</Button>
              </div>
              <div className="space-y-4">
                {serviceData.reviews.map((review) => (
                  <div key={review.id} className="rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{review.user}</h3>
                      <div className="flex items-center">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < review.rating ? "fill-primary text-primary" : "text-muted-foreground"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{review.date}</p>
                    <p className="mt-2">{review.comment}</p>
                  </div>
                ))}
              </div>
              <div className="flex justify-center">
                <Button variant="outline">Load More Reviews</Button>
              </div>
            </TabsContent>
            <TabsContent value="faq" className="mt-6">
              <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">What cleaning products do you use?</h3>
                  <p className="mt-2 text-muted-foreground">
                    We primarily use eco-friendly cleaning products that are safe for children and pets. If you have
                    specific products you'd like us to use, we're happy to accommodate.
                  </p>
                </div>
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">How long does a typical cleaning session take?</h3>
                  <p className="mt-2 text-muted-foreground">
                    A standard cleaning typically takes 2-3 hours for an average-sized home. Deep cleaning can take 4-6
                    hours depending on the size and condition of your home.
                  </p>
                </div>
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Do I need to be home during the cleaning?</h3>
                  <p className="mt-2 text-muted-foreground">
                    No, you don't need to be home. Many of our clients provide a key or access code. All our cleaners
                    are background-checked and insured.
                  </p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="policies" className="mt-6">
              <h2 className="text-2xl font-bold mb-6">Service Policies</h2>
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Cancellation Policy</h3>
                  <p className="mt-2 text-muted-foreground">
                    Cancellations made at least 24 hours before the scheduled service are eligible for a full refund.
                    Cancellations made less than 24 hours in advance may be subject to a cancellation fee.
                  </p>
                </div>
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Satisfaction Guarantee</h3>
                  <p className="mt-2 text-muted-foreground">
                    If you're not completely satisfied with our service, please let us know within 24 hours and we'll
                    re-clean any areas you're not happy with at no additional cost.
                  </p>
                </div>
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium">Insurance & Liability</h3>
                  <p className="mt-2 text-muted-foreground">
                    All our cleaners are fully insured. In the rare event of damage or breakage, please report it within
                    24 hours and we'll work with you to resolve the issue.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  )
}

export default ServiceDetailPage

