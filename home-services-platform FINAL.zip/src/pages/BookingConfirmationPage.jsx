"use client"

import { useState, useEffect } from "react"
import { useParams, Link } from "react-router-dom"
import Layout from "../components/layout/Layout"
import { Button } from "../components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card"
import { CheckCircle, Calendar, Clock, MapPin } from "lucide-react"
import { useServiceApi } from "../services/serviceApi"

function BookingConfirmationPage() {
  const { id: bookingId } = useParams()
  const serviceApi = useServiceApi()
  const [booking, setBooking] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchBooking = async () => {
      try {
        // In a real app, you would fetch the booking details from the API
        // For now, we'll use mock data
        const mockBooking = {
          id: bookingId,
          service: {
            id: 1,
            title: "Professional House Cleaning",
            provider: "CleanHome Services",
          },
          date: "2023-06-15T10:00:00Z",
          duration: "2 hours",
          address: "123 Main St, Dublin",
          price: 120,
          status: "confirmed",
          paymentStatus: "paid",
        }

        setBooking(mockBooking)
      } catch (error) {
        setError(error.message || "Failed to load booking details")
      } finally {
        setLoading(false)
      }
    }

    fetchBooking()
  }, [bookingId])

  if (loading) {
    return (
      <Layout>
        <div className="container py-8">
          <div className="flex justify-center">
            <p>Loading booking details...</p>
          </div>
        </div>
      </Layout>
    )
  }

  if (error) {
    return (
      <Layout>
        <div className="container py-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-destructive">Error</CardTitle>
              <CardDescription>{error}</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild>
                <Link to="/dashboard">Return to Dashboard</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="container max-w-2xl mx-auto px-4 py-8">
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <CheckCircle className="h-16 w-16 text-green-500" />
            </div>
            <CardTitle className="text-2xl">Booking Confirmed!</CardTitle>
            <CardDescription>Your booking has been successfully confirmed and paid for.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="rounded-lg border p-4">
              <h3 className="font-medium text-lg mb-4">Booking Details</h3>

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 mt-0.5 flex-shrink-0">
                    <Calendar className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">Date & Time</p>
                    <p className="text-muted-foreground">
                      {new Date(booking.date).toLocaleDateString()} at{" "}
                      {new Date(booking.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 mt-0.5 flex-shrink-0">
                    <Clock className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">Duration</p>
                    <p className="text-muted-foreground">{booking.duration}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 mt-0.5 flex-shrink-0">
                    <MapPin className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">Address</p>
                    <p className="text-muted-foreground">{booking.address}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-lg border p-4">
              <h3 className="font-medium text-lg mb-4">Service Information</h3>

              <div className="space-y-3">
                <div>
                  <p className="font-medium">Service</p>
                  <p className="text-muted-foreground">{booking.service.title}</p>
                </div>

                <div>
                  <p className="font-medium">Provider</p>
                  <p className="text-muted-foreground">{booking.service.provider}</p>
                </div>

                <div>
                  <p className="font-medium">Total Amount</p>
                  <p className="text-muted-foreground">€{booking.price}</p>
                </div>

                <div>
                  <p className="font-medium">Payment Status</p>
                  <div className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold bg-green-100 text-green-800">
                    {booking.paymentStatus}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <Button asChild className="w-full">
              <Link to="/dashboard">View All Bookings</Link>
            </Button>
            <Button variant="outline" asChild className="w-full">
              <Link to={`/chat`}>Contact Service Provider</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </Layout>
  )
}

export default BookingConfirmationPage

