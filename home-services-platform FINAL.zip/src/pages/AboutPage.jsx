import Layout from "../components/layout/Layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Link } from "react-router-dom"

function AboutPage() {
  return (
    <Layout>
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">About HomeShare</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                Connecting homeowners with trusted professionals and enabling intergenerational homesharing across
                Ireland
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold tracking-tight">Our Mission</h2>
              <p className="text-muted-foreground">
                At HomeShare, we're on a mission to transform how people access home services and housing solutions. We
                believe in creating a platform that not only connects homeowners with reliable service professionals but
                also fosters meaningful intergenerational connections through our innovative homesharing program.
              </p>
              <p className="text-muted-foreground">
                Our dual-purpose platform addresses two critical needs in today's society: access to trusted home
                services and affordable housing solutions for students while providing companionship and support for
                elderly homeowners.
              </p>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative h-[350px] w-full overflow-hidden rounded-xl bg-muted">
                <img
                  src="/placeholder.svg?height=350&width=600"
                  alt="Team members collaborating"
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tight">Our Values</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                The principles that guide everything we do
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Trust & Safety</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  We prioritize trust and safety in all our services. Every service professional and homesharing
                  participant undergoes thorough background checks and verification processes.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Community Connection</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  We believe in the power of community and intergenerational connections to enrich lives and create
                  support networks that benefit everyone involved.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Quality Service</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  We're committed to providing high-quality services that meet and exceed expectations, ensuring
                  customer satisfaction in every interaction.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tight">Our Team</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                Meet the dedicated people behind HomeShare
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { name: "Sarah Johnson", role: "Founder & CEO", image: "/placeholder.svg?height=200&width=200" },
              { name: "Michael O'Brien", role: "CTO", image: "/placeholder.svg?height=200&width=200" },
              { name: "Emma Walsh", role: "Head of Homesharing", image: "/placeholder.svg?height=200&width=200" },
              {
                name: "David Murphy",
                role: "Service Operations Manager",
                image: "/placeholder.svg?height=200&width=200",
              },
            ].map((member) => (
              <Card key={member.name} className="text-center">
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-4">
                    <div className="h-24 w-24 overflow-hidden rounded-full">
                      <img
                        src={member.image || "/placeholder.svg"}
                        alt={member.name}
                        className="object-cover w-full h-full"
                      />
                    </div>
                  </div>
                  <CardTitle>{member.name}</CardTitle>
                  <CardDescription>{member.role}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tight">Join Our Community</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                Whether you're looking for home services, want to offer your professional skills, or are interested in
                homesharing, we'd love to welcome you to our community.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" asChild>
                <Link to="/register">Sign Up Today</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  )
}

export default AboutPage

