"use client"

import { createContext, useContext, useState, useEffect } from "react"
import { useToast } from "../components/ui/use-toast"

const AuthContext = createContext(undefined)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const { toast } = useToast()

  // Check if user is already logged in
  useEffect(() => {
    const checkAuthStatus = async () => {
      const storedUser = localStorage.getItem("user")

      if (storedUser) {
        try {
          setUser(JSON.parse(storedUser))
        } catch (err) {
          console.error("Error parsing stored user:", err)
          localStorage.removeItem("user")
        }
      }
      setLoading(false)
    }

    checkAuthStatus()
  }, [])

  const login = async (email, password) => {
    setLoading(true)
    setError(null)
    try {
      // Mock login for development
      const mockUser = {
        id: "user-123",
        name: "John Doe",
        email,
        role: "customer",
        token: "mock-jwt-token",
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
      return mockUser
    } catch (err) {
      const errorMessage = err.message || "Failed to login. Please check your credentials."
      setError(errorMessage)
      throw new Error(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const register = async (userData) => {
    setLoading(true)
    setError(null)
    try {
      // Mock registration for development
      const mockUser = {
        id: "user-" + Math.floor(Math.random() * 1000),
        name: userData.name,
        email: userData.email,
        role: userData.role || "customer",
        token: "mock-jwt-token",
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
      return mockUser
    } catch (err) {
      const errorMessage = err.message || "Failed to register. Please try again."
      setError(errorMessage)
      throw new Error(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  const updateProfile = async (profileData) => {
    setLoading(true)
    try {
      // Mock profile update
      const updatedUser = { ...user, ...profileData }
      setUser(updatedUser)
      localStorage.setItem("user", JSON.stringify(updatedUser))
      return updatedUser
    } catch (err) {
      const errorMessage = err.message || "Failed to update profile."
      setError(errorMessage)
      throw new Error(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        updateProfile,
        loading,
        error,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

