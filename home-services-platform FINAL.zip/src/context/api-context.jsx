"use client"

import { createContext, useContext } from "react"
import axios from "axios"

const ApiContext = createContext(undefined)

export function ApiProvider({ children }) {
  const api = axios.create({
    baseURL: "http://localhost:5000/api",
    headers: {
      "Content-Type": "application/json",
    },
  })

  // Add auth token to requests if user is logged in
  api.interceptors.request.use(
    (config) => {
      const storedUser = localStorage.getItem("user")
      if (storedUser) {
        const user = JSON.parse(storedUser)
        if (user?.token) {
          config.headers.Authorization = `Bearer ${user.token}`
        }
      }
      return config
    },
    (error) => Promise.reject(error),
  )

  // Handle response errors
  api.interceptors.response.use(
    (response) => response,
    (error) => {
      // Handle 401 Unauthorized errors
      if (error.response && error.response.status === 401) {
        // Redirect to login or refresh token
        console.error("Unauthorized access, please login again")
      }
      return Promise.reject(error)
    },
  )

  return <ApiContext.Provider value={{ api }}>{children}</ApiContext.Provider>
}

export const useApi = () => {
  const context = useContext(ApiContext)
  if (context === undefined) {
    throw new Error("useApi must be used within an ApiProvider")
  }
  return context
}

