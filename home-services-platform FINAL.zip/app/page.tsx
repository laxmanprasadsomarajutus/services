"use client"

import ProtectedRoute from "../src/components/ProtectedRoute"

export default function SyntheticV0PageForDeployment() {
  return <ProtectedRoute />
}