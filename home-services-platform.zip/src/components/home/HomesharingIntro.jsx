import { Link } from "react-router-dom"
import { Button } from "../ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card"
import { Home, GraduationCap, Heart, Shield } from "lucide-react"

export function HomesharingIntro() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Intergenerational Homesharing</h2>
              <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                Connect elderly homeowners with students seeking affordable accommodation in a mutually beneficial
                arrangement.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link to="/homesharing/householders">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  I Have a Home to Share
                </Button>
              </Link>
              <Link to="/homesharing/homesharers">
                <Button size="lg" variant="outline">
                  I Need Accommodation
                </Button>
              </Link>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 text-primary">
                  <Home className="h-6 w-6" />
                  <CardTitle className="text-lg">For Householders</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Share your home, receive help with daily tasks, and enjoy companionship while earning extra income.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 text-primary">
                  <GraduationCap className="h-6 w-6" />
                  <CardTitle className="text-lg">For Students</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Find affordable accommodation and make a meaningful difference in an elderly person's life.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 text-primary">
                  <Heart className="h-6 w-6" />
                  <CardTitle className="text-lg">Mutual Benefits</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Create intergenerational connections that enrich lives and build community bonds.
                </CardDescription>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 text-primary">
                  <Shield className="h-6 w-6" />
                  <CardTitle className="text-lg">Safe & Secure</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  All participants undergo thorough background checks and verification processes.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}

