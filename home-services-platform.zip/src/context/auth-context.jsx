"use client"

import { createContext, useContext, useState, useEffect } from "react"

const AuthContext = createContext(undefined)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Check if user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  const login = async (email, password) => {
    setLoading(true)
    setError(null)
    try {
      // This would be replaced with an actual API call
      // For demo purposes, we're simulating a successful login
      const mockUser = {
        id: "user-123",
        name: "John Doe",
        email,
        role: "customer",
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } catch (err) {
      setError("Failed to login. Please check your credentials.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const register = async (userData) => {
    setLoading(true)
    setError(null)
    try {
      // This would be replaced with an actual API call
      // For demo purposes, we're simulating a successful registration
      const mockUser = {
        id: "user-" + Math.floor(Math.random() * 1000),
        name: userData.name,
        email: userData.email,
        role: userData.role || "customer",
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } catch (err) {
      setError("Failed to register. Please try again.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading, error }}>{children}</AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

