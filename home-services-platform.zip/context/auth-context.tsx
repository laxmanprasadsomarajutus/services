"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

type User = {
  id: string
  name?: string
  email: string
  role: "customer" | "professional" | "householder" | "homesharer" | "admin"
} | null

type AuthContextType = {
  user: User
  login: (email: string, password: string) => Promise<void>
  register: (userData: any) => Promise<void>
  logout: () => void
  loading: boolean
  error: string | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Check if user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string) => {
    setLoading(true)
    setError(null)
    try {
      // This would be replaced with an actual API call
      // For demo purposes, we're simulating a successful login
      const mockUser = {
        id: "user-123",
        name: "John Doe",
        email,
        role: "customer" as const,
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } catch (err) {
      setError("Failed to login. Please check your credentials.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const register = async (userData: any) => {
    setLoading(true)
    setError(null)
    try {
      // This would be replaced with an actual API call
      // For demo purposes, we're simulating a successful registration
      const mockUser = {
        id: "user-" + Math.floor(Math.random() * 1000),
        name: userData.name,
        email: userData.email,
        role: userData.role || ("customer" as const),
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setUser(mockUser)
      localStorage.setItem("user", JSON.stringify(mockUser))
    } catch (err) {
      setError("Failed to register. Please try again.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading, error }}>{children}</AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

