import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MainNav } from "@/components/main-nav"
import { Footer } from "@/components/footer"
import { Home, GraduationCap, MapPin, Calendar, Heart } from "lucide-react"

const householders = [
  {
    id: 1,
    name: "Margaret, 72",
    location: "Dublin City Centre",
    accommodation: "Private room in 3-bed house",
    expectations: "Light housekeeping, occasional companionship",
    availability: "Available from September",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Thomas, 68",
    location: "Cork City",
    accommodation: "Private room in 2-bed apartment",
    expectations: "Help with groceries, tech support",
    availability: "Available from October",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Elizabeth, 75",
    location: "Galway",
    accommodation: "Private room in 4-bed house",
    expectations: "Garden help, shared meals twice weekly",
    availability: "Available immediately",
    image: "/placeholder.svg?height=200&width=200",
  },
]

const homesharers = [
  {
    id: 1,
    name: "James, 22",
    university: "Trinity College Dublin",
    course: "Computer Science, Year 3",
    skills: "Tech support, cooking, DIY",
    availability: "Looking from September",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Sophie, 19",
    university: "University College Cork",
    course: "Nursing, Year 1",
    skills: "First aid, cooking, elderly care experience",
    availability: "Looking from October",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Miguel, 24",
    university: "NUI Galway",
    course: "Business, Year 4",
    skills: "Gardening, driving, home maintenance",
    availability: "Looking immediately",
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function HomesharingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <MainNav />
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                    Intergenerational Homesharing
                  </h1>
                  <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                    Creating meaningful connections between generations while solving housing needs.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/homesharing/householders">
                    <Button size="lg" className="bg-primary hover:bg-primary/90">
                      <Home className="mr-2 h-5 w-5" />I Have a Home to Share
                    </Button>
                  </Link>
                  <Link href="/homesharing/homesharers">
                    <Button size="lg" variant="outline">
                      <GraduationCap className="mr-2 h-5 w-5" />I Need Accommodation
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[350px] w-full overflow-hidden rounded-xl bg-muted">
                  <img
                    src="/placeholder.svg?height=350&width=600"
                    alt="Elderly person and student sharing a home"
                    className="object-cover w-full h-full"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">How It Works</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Our homesharing program connects elderly homeowners with students for mutual benefit
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-3 md:gap-12 mt-8">
              <div className="flex flex-col items-center space-y-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Home className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold">Create a Profile</h3>
                <p className="text-muted-foreground">
                  Sign up and create your profile as either a householder or homesharer.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Heart className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold">Find Your Match</h3>
                <p className="text-muted-foreground">
                  Browse profiles or let our algorithm suggest compatible matches.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Calendar className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold">Create an Agreement</h3>
                <p className="text-muted-foreground">
                  Meet in person and use our tools to create a homesharing agreement.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <Tabs defaultValue="householders" className="w-full">
              <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Browse Profiles</h2>
                  <p className="max-w-[900px] text-muted-foreground md:text-xl">Find your perfect homesharing match</p>
                </div>
                <TabsList className="grid w-full max-w-md grid-cols-2">
                  <TabsTrigger value="householders">
                    <Home className="mr-2 h-4 w-4" />
                    Householders
                  </TabsTrigger>
                  <TabsTrigger value="homesharers">
                    <GraduationCap className="mr-2 h-4 w-4" />
                    Homesharers
                  </TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="householders" className="w-full">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {householders.map((householder) => (
                    <Card key={householder.id} className="h-full overflow-hidden">
                      <div className="flex justify-center p-6">
                        <div className="h-32 w-32 overflow-hidden rounded-full">
                          <img
                            src={householder.image || "/placeholder.svg"}
                            alt={householder.name}
                            className="object-cover w-full h-full"
                          />
                        </div>
                      </div>
                      <CardHeader className="p-4 pb-0">
                        <CardTitle className="text-xl">{householder.name}</CardTitle>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4 mr-1" />
                          {householder.location}
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Accommodation:</strong> {householder.accommodation}
                          </p>
                          <p>
                            <strong>Expectations:</strong> {householder.expectations}
                          </p>
                          <p>
                            <strong>Availability:</strong> {householder.availability}
                          </p>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4">
                        <Button className="w-full">View Profile</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
                <div className="mt-8 flex justify-center">
                  <Button variant="outline">View More Householders</Button>
                </div>
              </TabsContent>
              <TabsContent value="homesharers" className="w-full">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {homesharers.map((homesharer) => (
                    <Card key={homesharer.id} className="h-full overflow-hidden">
                      <div className="flex justify-center p-6">
                        <div className="h-32 w-32 overflow-hidden rounded-full">
                          <img
                            src={homesharer.image || "/placeholder.svg"}
                            alt={homesharer.name}
                            className="object-cover w-full h-full"
                          />
                        </div>
                      </div>
                      <CardHeader className="p-4 pb-0">
                        <CardTitle className="text-xl">{homesharer.name}</CardTitle>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <GraduationCap className="h-4 w-4 mr-1" />
                          {homesharer.university}
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Course:</strong> {homesharer.course}
                          </p>
                          <p>
                            <strong>Skills:</strong> {homesharer.skills}
                          </p>
                          <p>
                            <strong>Availability:</strong> {homesharer.availability}
                          </p>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4">
                        <Button className="w-full">View Profile</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
                <div className="mt-8 flex justify-center">
                  <Button variant="outline">View More Homesharers</Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Success Stories</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Read about successful homesharing matches
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Mary & Sarah</CardTitle>
                  <CardDescription>Dublin City Centre</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    "I was living alone after my husband passed away and the house felt too empty. Sarah has brought so
                    much joy into my life. She helps me with technology and grocery shopping, and I cook for her
                    sometimes. It's a perfect arrangement."
                  </p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="text-sm text-muted-foreground">Mary, 78</p>
                  <p className="text-sm text-muted-foreground">Homesharing for 1.5 years</p>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>John & Michael</CardTitle>
                  <CardDescription>Galway</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    "As a student, finding affordable accommodation was a nightmare. Living with John has been amazing.
                    I help him with garden maintenance and some household tasks, and in return I get a comfortable place
                    to live and a mentor who gives great life advice."
                  </p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="text-sm text-muted-foreground">Michael, 22</p>
                  <p className="text-sm text-muted-foreground">Homesharing for 10 months</p>
                </CardFooter>
              </Card>
            </div>
            <div className="mt-8 flex justify-center">
              <Link href="/homesharing/success-stories">
                <Button variant="outline">Read More Stories</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

