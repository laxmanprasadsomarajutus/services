import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { MainNav } from "@/components/main-nav"
import { Footer } from "@/components/footer"
import { Search, MapPin, Star, Filter } from 'lucide-react'

const services = [
  {
    id: 1,
    title: "Professional House Cleaning",
    category: "Cleaning",
    rating: 4.8,
    reviewCount: 124, // Changed from "reviews" to "reviewCount"
    price: "From €60",
    location: "Dublin",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    title: "Bathroom Plumbing Repair",
    category: "Plumbing",
    rating: 4.7,
    reviewCount: 98, // Changed from "reviews" to "reviewCount"
    price: "From €85",
    location: "Cork",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    title: "Electrical Fixture Installation",
    category: "Electrical",
    rating: 4.9,
    reviewCount: 156, // Changed from "reviews" to "reviewCount"
    price: "From €75",
    location: "Galway",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 4,
    title: "Furniture Assembly",
    category: "Handyman",
    rating: 4.6,
    reviewCount: 87, // Changed from "reviews" to "reviewCount"
    price: "From €50",
    location: "Dublin",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 5,
    title: "Interior Painting",
    category: "Painting",
    rating: 4.8,
    reviewCount: 112, // Changed from "reviews" to "reviewCount"
    price: "From €120",
    location: "Limerick",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 6,
    title: "Refrigerator Repair",
    category: "Appliances",
    rating: 4.7,
    reviewCount: 76, // Changed from "reviews" to "reviewCount"
    price: "From €90",
    location: "Dublin",
    image: "/placeholder.svg?height=200&width=300",
  },
]

export default function ServicesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <MainNav />
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Find Home Services</h1>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Book trusted professionals for all your home service needs
                </p>
              </div>
              <div className="w-full max-w-2xl space-y-2">
                <div className="flex w-full max-w-sm items-center space-x-2 mx-auto">
                  <Input type="text" placeholder="What service do you need?" className="flex-1" />
                  <Button type="submit">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                </div>
                <div className="flex flex-wrap justify-center gap-2">
                  {["Cleaning", "Plumbing", "Electrical", "Handyman", "Painting"].map((category) => (
                    <Button key={category} variant="outline" size="sm">
                      {category}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold tracking-tight">Available Services</h2>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((service) => (
                <Link key={service.id} href={`/services/${service.id}`}>
                  <Card className="h-full overflow-hidden transition-all hover:shadow-md">
                    <div className="aspect-video w-full overflow-hidden">
                      <img
                        src={service.image || "/placeholder.svg"}
                        alt={service.title}
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <CardHeader className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="rounded-full px-2 py-1 text-xs font-medium bg-primary/10 text-primary">
                          {service.category}
                        </div>
                        <div className="flex items-center text-sm">
                          <Star className="h-4 w-4 fill-primary text-primary mr-1" />
                          <span>{service.rating}</span>
                          <span className="text-muted-foreground ml-1">({service.reviewCount})</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4 mr-1" />
                        {service.location}
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 flex items-center justify-between">
                      <p className="font-medium">{service.price}</p>
                      <Button size="sm">Book Now</Button>
                    </CardFooter>
                  </Card>
                </Link>
              ))}
            </div>
            <div className="mt-12 flex justify-center">
              <Button variant="outline">Load More</Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

