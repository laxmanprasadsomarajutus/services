import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Droplet, Zap, Wrench, Paintbrush, Refrigerator, Wifi, Flower2, Dog, Bell } from "lucide-react"

const services = [
  {
    title: "Cleaning",
    description: "Standard, Deep, Move-in/Move-out, Post-Renovation",
    icon: <Droplet className="h-6 w-6" />,
    href: "/services/cleaning",
  },
  {
    title: "Plumbing",
    description: "Tap/Leak Repair, Drain Cleaning, Bathroom Fittings",
    icon: <Droplet className="h-6 w-6" />,
    href: "/services/plumbing",
  },
  {
    title: "Electrical",
    description: "Fixtures, Circuit Repair, Smart Lighting, Appliance Setup",
    icon: <Zap className="h-6 w-6" />,
    href: "/services/electrical",
  },
  {
    title: "Handyman",
    description: "Furniture Assembly, TV Mounting, Minor Repairs",
    icon: <Wrench className="h-6 w-6" />,
    href: "/services/handyman",
  },
  {
    title: "Painting",
    description: "Interior/Exterior, Wallpaper, Patchwork",
    icon: <Paintbrush className="h-6 w-6" />,
    href: "/services/painting",
  },
  {
    title: "Appliances",
    description: "Installation & Repair for kitchen/laundry devices",
    icon: <Refrigerator className="h-6 w-6" />,
    href: "/services/appliances",
  },
  {
    title: "Smart Home",
    description: "Thermostats, Cameras, Wi-Fi, Voice Assistants",
    icon: <Wifi className="h-6 w-6" />,
    href: "/services/smart-home",
  },
  {
    title: "Gardening",
    description: "Lawn Mowing, Hedge Trimming, Gutter Cleaning",
    icon: <Flower2 className="h-6 w-6" />,
    href: "/services/gardening",
  },
  {
    title: "Pet Care",
    description: "Grooming, Walking, Sitting",
    icon: <Dog className="h-6 w-6" />,
    href: "/services/pet-care",
  },
  {
    title: "Emergency",
    description: "24/7 Electrician, Plumber, Locksmith",
    icon: <Bell className="h-6 w-6" />,
    href: "/services/emergency",
  },
]

export function ServiceCategories() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Services</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Browse our wide range of professional home services
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mt-8">
          {services.map((service) => (
            <Link key={service.title} href={service.href} className="group">
              <Card className="h-full transition-all hover:shadow-md">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="p-2 rounded-full bg-primary/10 text-primary">{service.icon}</div>
                    <CardTitle>{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>{service.description}</CardDescription>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

